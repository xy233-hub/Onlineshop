USE `seller_management_test`;

-- 清空现有数据
DELETE FROM purchase_intents;
DELETE FROM products;
DELETE FROM seller;

-- 插入测试商家 (密码: Admin123456)
INSERT INTO `seller` (`username`, `password`) 
VALUES (
  'admin', 
  '$2a$12$ycJEdpJ1TYxBzDCmuGju2eUbTP.vm0yNYYyFpK3ahxsCLq9d2Iq32'
);

-- 插入测试商品
INSERT INTO products (seller_id, product_name, product_desc, image_url, price, product_status) 
VALUES 
(1, '笔记本电脑', '高性能游戏笔记本', 'https://picsum.photos/400/300', 5999.00, 'online'),
(1, '智能手机', '最新款5G手机', 'https://picsum.photos/401/300', 3999.00, 'online'),
(1, '无线耳机', '降噪蓝牙耳机', 'https://picsum.photos/402/300', 899.00, 'frozen'),
(1, '平板电脑', '便携办公学习', 'https://picsum.photos/403/300', 2999.00, 'sold'),
(1, '智能手表', '健康监测运动', 'https://picsum.photos/404/300', 1299.00, 'online');

-- 插入测试购买意向
INSERT INTO `purchase_intents` (`product_id`, `customer_name`, `customer_phone`, `customer_address`, `purchase_status`) 
VALUES
(1, '张三', '13800138001', '北京市朝阳区建国路100号', 'pending'),
(1, '李四', '13800138002', '上海市浦东新区陆家嘴', 'success'),
(2, '王五', '13800138003', '广州市天河区珠江新城', 'pending'),
(3, '赵六', '13800138004', '深圳市南山区科技园', 'failed'),
(5, '钱七', '13800138005', '杭州市西湖区文三路', 'pending');