const TestHelper = require('./test_helper');
const { test, expect, beforeAll, afterAll, beforeEach } = require('@jest/globals');

describe('商品管理功能测试', () => {
    let helper;

    beforeAll(async () => {
        helper = new TestHelper();
        await helper.initDatabase();
    });

    beforeEach(async () => {
        await helper.cleanupTestData();
    });

    afterAll(async () => {
        await helper.close();
    });

    test('TC-PRODUCT-001: 商品数据完整性测试', async () => {
        const products = await helper.query('SELECT * FROM products');
        
        expect(products.length).toBeGreaterThan(0);
        
        const product = products[0];
        expect(product).toHaveProperty('product_id');
        expect(product).toHaveProperty('seller_id');
        expect(product).toHaveProperty('product_name');
        expect(product).toHaveProperty('product_desc');
        expect(product).toHaveProperty('image_url');
        expect(product).toHaveProperty('price');
        expect(product).toHaveProperty('product_status');
        
        console.log(` TC-PRODUCT-001: 商品数据完整性测试通过 - 共 ${products.length} 个商品`);
    });

    test('TC-PRODUCT-002: 商品状态枚举验证', async () => {
        const statuses = await helper.query('SELECT DISTINCT product_status FROM products');
        const validStatuses = ['online', 'frozen', 'sold'];
        
        statuses.forEach(status => {
            expect(validStatuses).toContain(status.product_status);
        });
        
        console.log(' TC-PRODUCT-002: 商品状态枚举验证通过');
    });

    test('TC-PRODUCT-003: 商品价格验证', async () => {
        const products = await helper.query('SELECT * FROM products WHERE price IS NOT NULL');
        
        products.forEach(product => {
            expect(parseFloat(product.price)).toBeGreaterThan(0);
            expect(product.price).toMatch(/^\d+\.?\d{0,2}$/); // 价格格式验证
        });
        
        console.log(' TC-PRODUCT-003: 商品价格验证通过');
    });

    test('TC-PRODUCT-004: 商品外键关联验证', async () => {
        const products = await helper.query(`
            SELECT p.*, s.username 
            FROM products p 
            JOIN seller s ON p.seller_id = s.seller_id
        `);
        
        expect(products.length).toBeGreaterThan(0);
        products.forEach(product => {
            expect(product.username).toBe('admin');
        });
        
        console.log(' TC-PRODUCT-004: 商品外键关联验证通过');
    });

    test('TC-PRODUCT-005: 商品状态分布测试', async () => {
        const statusCounts = await helper.query(`
            SELECT product_status, COUNT(*) as count 
            FROM products 
            GROUP BY product_status
        `);
        
        console.log('商品状态分布:');
        statusCounts.forEach(status => {
            console.log(`  - ${status.product_status}: ${status.count} 个`);
        });
        
        expect(statusCounts.length).toBeGreaterThan(0);
        console.log(' TC-PRODUCT-005: 商品状态分布测试通过');
    });
});