const TestHelper = require('./test_helper');
const { test, expect, beforeAll, afterAll } = require('@jest/globals');

describe('环境验证测试', () => {
    let helper;

    beforeAll(async () => {
        helper = new TestHelper();
        await helper.initDatabase();
    });

    test('TC-ENV-001: 数据库连接测试', async () => {
        const result = await helper.query('SELECT 1 as connection_test');
        expect(result[0].connection_test).toBe(1);
        console.log(' TC-ENV-001: 数据库连接测试通过');
    });

    test('TC-ENV-002: 数据库表结构验证', async () => {
        const tables = await helper.query('SHOW TABLES');
        const tableNames = tables.map(row => Object.values(row)[0]);
        
        expect(tableNames).toContain('seller');
        expect(tableNames).toContain('products');
        expect(tableNames).toContain('purchase_intents');
        
        console.log(' TC-ENV-002: 数据库表结构验证通过');
    });

    test('TC-ENV-003: 测试数据验证', async () => {
        const sellers = await helper.query('SELECT * FROM seller');
        const products = await helper.query('SELECT * FROM products');
        const intents = await helper.query('SELECT * FROM purchase_intents');
        
        expect(sellers.length).toBeGreaterThan(0);
        expect(products.length).toBeGreaterThan(0);
        expect(intents.length).toBeGreaterThan(0);
        
        console.log(` TC-ENV-003: 测试数据验证通过 - 卖家: ${sellers.length}, 商品: ${products.length}, 意向: ${intents.length}`);
    });

    test('TC-ENV-004: 密码加密验证', async () => {
        const sellers = await helper.query('SELECT * FROM seller WHERE username = ?', ['admin']);
        const seller = sellers[0];
        
        // 验证密码是BCrypt加密格式
        expect(seller.password).toMatch(/^\$2[ayb]\$.{56}$/);
        
        // 验证密码正确性
        const isPasswordValid = await helper.verifyPassword('Admin123456', seller.password);
        expect(isPasswordValid).toBe(true);
        
        console.log(' TC-ENV-004: 密码加密验证通过');
    });

    afterAll(async () => {
        await helper.close();
    });
});