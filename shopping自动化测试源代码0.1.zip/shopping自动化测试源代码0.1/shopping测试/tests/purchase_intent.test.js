const TestHelper = require('./test_helper');
const { test, expect, beforeAll, afterAll, beforeEach } = require('@jest/globals');

describe('购买意向管理功能测试', () => {
    let helper;

    beforeAll(async () => {
        helper = new TestHelper();
        await helper.initDatabase();
    });

    beforeEach(async () => {
        await helper.cleanupTestData();
    });

    afterAll(async () => {
        await helper.close();
    });

    test('TC-INTENT-001: 购买意向数据完整性测试', async () => {
        const intents = await helper.query('SELECT * FROM purchase_intents');
        
        expect(intents.length).toBeGreaterThan(0);
        
        const intent = intents[0];
        expect(intent).toHaveProperty('purchase_id');
        expect(intent).toHaveProperty('product_id');
        expect(intent).toHaveProperty('customer_name');
        expect(intent).toHaveProperty('customer_phone');
        expect(intent).toHaveProperty('customer_address');
        expect(intent).toHaveProperty('purchase_status');
        
        console.log(` TC-INTENT-001: 购买意向数据完整性测试通过 - 共 ${intents.length} 个意向`);
    });

    test('TC-INTENT-002: 购买意向状态枚举验证', async () => {
        const statuses = await helper.query('SELECT DISTINCT purchase_status FROM purchase_intents');
        const validStatuses = ['pending', 'success', 'failed'];
        
        statuses.forEach(status => {
            expect(validStatuses).toContain(status.purchase_status);
        });
        
        console.log(' TC-INTENT-002: 购买意向状态枚举验证通过');
    });

    test('TC-INTENT-003: 客户信息验证', async () => {
        const intents = await helper.query('SELECT * FROM purchase_intents');
        
        intents.forEach(intent => {
            expect(intent.customer_name.length).toBeGreaterThan(0);
            expect(intent.customer_phone.length).toBeGreaterThan(0);
            expect(intent.customer_address.length).toBeGreaterThan(0);
            
            // 手机号格式验证（简单的11位数字验证）
            expect(intent.customer_phone).toMatch(/^\d{11}$/);
        });
        
        console.log(' TC-INTENT-003: 客户信息验证通过');
    });

    test('TC-INTENT-004: 购买意向与商品关联验证', async () => {
        const intents = await helper.query(`
            SELECT pi.*, p.product_name, p.product_status 
            FROM purchase_intents pi 
            JOIN products p ON pi.product_id = p.product_id
        `);
        
        expect(intents.length).toBeGreaterThan(0);
        
        intents.forEach(intent => {
            expect(intent.product_name).toBeDefined();
            expect(intent.product_status).toBeDefined();
        });
        
        console.log(' TC-INTENT-004: 购买意向与商品关联验证通过');
    });

    test('TC-INTENT-005: 购买意向状态分布测试', async () => {
        const statusCounts = await helper.query(`
            SELECT purchase_status, COUNT(*) as count 
            FROM purchase_intents 
            GROUP BY purchase_status
        `);
        
        console.log('购买意向状态分布:');
        statusCounts.forEach(status => {
            console.log(`  - ${status.purchase_status}: ${status.count} 个`);
        });
        
        expect(statusCounts.length).toBeGreaterThan(0);
        console.log(' TC-INTENT-005: 购买意向状态分布测试通过');
    });
});