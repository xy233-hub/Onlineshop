const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');
const axios = require('axios');

class TestHelper {
    constructor() {
        this.dbConfig = {
            host: process.env.DB_HOST || 'localhost',
            user: process.env.DB_USER || 'root',
            password: process.env.DB_PASSWORD || '12345', // 用你的密码
            database: process.env.DB_NAME || 'seller_management_test'
        };
        
        this.apiBaseUrl = process.env.API_BASE_URL || 'http://localhost:3000/api';
        this.authToken = null;
        this.connection = null;
    }

    async initDatabase() {
        try {
            this.connection = await mysql.createConnection(this.dbConfig);
            console.log(' 数据库连接成功');
            return this.connection;
        } catch (error) {
            console.error(' 数据库连接失败:', error.message);
            throw error;
        }
    }

    async cleanupTestData() {
        if (!this.connection) return;
        
        try {
            await this.connection.execute('DELETE FROM purchase_intents WHERE purchase_id > 5');
            await this.connection.execute('DELETE FROM products WHERE product_id > 5');
            await this.connection.execute('DELETE FROM seller WHERE seller_id > 1');
            console.log(' 测试数据清理完成');
        } catch (error) {
            console.error(' 数据清理失败:', error.message);
        }
    }

    async close() {
        if (this.connection) {
            await this.connection.end();
            console.log(' 数据库连接已关闭');
        }
    }

    async apiRequest(method, endpoint, data = null, requiresAuth = false) {
        const config = {
            method: method.toLowerCase(),
            url: `${this.apiBaseUrl}${endpoint}`,
            headers: {
                'Content-Type': 'application/json'
            }
        };

        if (requiresAuth && this.authToken) {
            config.headers.Authorization = `Bearer ${this.authToken}`;
        }

        if (data) {
            config.data = data;
        }

        try {
            const response = await axios(config);
            return {
                code: response.status,
                message: response.data?.message || '',
                data: response.data?.data || null
            };
        } catch (error) {
            if (error.response) {
                return {
                    code: error.response.status,
                    message: error.response.data?.message || error.message,
                    data: null
                };
            }
            return {
                code: 500,
                message: `Network Error: ${error.message}`,
                data: null
            };
        }
    }

    async sellerLogin(username = 'admin', password = 'Admin123456') {
        const result = await this.apiRequest('post', '/seller/login', {
            username,
            password
        });
        
        if (result.code === 200 && result.data && result.data.token) {
            this.authToken = result.data.token;
            console.log(` 商家登录成功: ${username}`);
        }
        
        return result;
    }

    async query(sql, params = []) {
        if (!this.connection) {
            throw new Error('数据库未连接');
        }
        const [rows] = await this.connection.execute(sql, params);
        return rows;
    }

    async verifyPassword(plainPassword, hashedPassword) {
        return await bcrypt.compare(plainPassword, hashedPassword);
    }
}

module.exports = TestHelper;