const TestHelper = require('./test_helper');
const { test, expect, beforeAll, afterAll } = require('@jest/globals');

describe('顾客功能测试', () => {
    let helper;

    beforeAll(async () => {
        helper = new TestHelper();
        await helper.initDatabase();
    });

    afterAll(async () => {
        await helper.close();
    });

    test('TC-CUSTOMER-001: 在线商品查询测试', async () => {
        const onlineProducts = await helper.query(`
            SELECT * FROM products 
            WHERE product_status = 'online'
        `);
        
        expect(onlineProducts.length).toBeGreaterThan(0);
        
        onlineProducts.forEach(product => {
            expect(product.product_status).toBe('online');
            expect(parseFloat(product.price)).toBeGreaterThan(0);
            expect(product.product_name.length).toBeGreaterThan(0);
        });
        
        console.log(` TC-CUSTOMER-001: 在线商品查询测试通过 - 共 ${onlineProducts.length} 个在线商品`);
    });

    test('TC-CUSTOMER-002: 商品状态过滤测试', async () => {
        const frozenProducts = await helper.query(`SELECT * FROM products WHERE product_status = 'frozen'`);
        const soldProducts = await helper.query(`SELECT * FROM products WHERE product_status = 'sold'`);
        
        // 验证冻结商品
        frozenProducts.forEach(product => {
            expect(product.product_status).toBe('frozen');
        });
        
        // 验证已售出商品
        soldProducts.forEach(product => {
            expect(product.product_status).toBe('sold');
        });
        
        console.log(` TC-CUSTOMER-002: 商品状态过滤测试通过 - 冻结: ${frozenProducts.length} 个, 售出: ${soldProducts.length} 个`);
    });

    test('TC-CUSTOMER-003: 商品信息完整性测试', async () => {
        const products = await helper.query('SELECT * FROM products');
        
        products.forEach(product => {
            // 基本信息验证
            expect(product.product_name.length).toBeGreaterThan(0);
            expect(product.product_desc.length).toBeGreaterThan(0);
            expect(product.image_url.length).toBeGreaterThan(0);
            expect(parseFloat(product.price)).toBeGreaterThan(0);
            
            // 图片URL格式验证
            expect(product.image_url).toMatch(/^https?:\/\//);
        });
        
        console.log(' TC-CUSTOMER-003: 商品信息完整性测试通过');
    });

    test('TC-CUSTOMER-004: 购买意向提交数据验证', async () => {
        const intents = await helper.query('SELECT * FROM purchase_intents');
        
        intents.forEach(intent => {
            // 客户信息验证
            expect(intent.customer_name.trim().length).toBeGreaterThan(0);
            expect(intent.customer_phone.trim().length).toBeGreaterThan(0);
            expect(intent.customer_address.trim().length).toBeGreaterThan(0);
            
            // 关联商品验证
            expect(intent.product_id).toBeGreaterThan(0);
        });
        
        console.log(' TC-CUSTOMER-004: 购买意向提交数据验证通过');
    });
});