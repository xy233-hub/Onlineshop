const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');

async function setupDatabase() {
    const password = '12345';
    
    try {
        // 创建主连接
        const connection = await mysql.createConnection({
            host: 'localhost',
            user: 'root',
            password: password,
            multipleStatements: true  // 允许执行多条SQL语句
        });

        console.log(' 连接到 MySQL 服务器');

        // 创建数据库
        await connection.execute('CREATE DATABASE IF NOT EXISTS `seller_management_test`');
        console.log(' 数据库创建成功');

        // 使用新数据库
        await connection.execute('USE `seller_management_test`');
        console.log(' 切换到测试数据库');

        // 读取并执行表结构SQL - 使用query而不是execute
        console.log(' 创建表结构...');
        const schemaSql = fs.readFileSync(path.join(__dirname, '../test_database.sql'), 'utf8');
        
        // 移除注释和空行，然后执行整个SQL
        const cleanSchemaSql = schemaSql
            .replace(/--.*$/gm, '')  // 移除行注释
            .replace(/\/\*[\s\S]*?\*\//g, '')  // 移除块注释
            .trim();
        
        await connection.query(cleanSchemaSql);
        console.log(' 表结构创建成功');

        // 读取并执行种子数据SQL
        console.log(' 插入测试数据...');
        const seedSql = fs.readFileSync(path.join(__dirname, '../test_data/seed_data.sql'), 'utf8');
        
        const cleanSeedSql = seedSql
            .replace(/--.*$/gm, '')
            .replace(/\/\*[\s\S]*?\*\//g, '')
            .trim();
        
        await connection.query(cleanSeedSql);
        console.log(' 测试数据插入成功');

        await connection.end();
        console.log(' 数据库初始化完成！');
        
    } catch (error) {
        console.error(' 数据库初始化失败:', error.message);
        console.error('错误详情:', error);
    }
}

setupDatabase();