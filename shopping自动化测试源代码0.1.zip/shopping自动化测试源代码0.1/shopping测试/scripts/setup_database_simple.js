const mysql = require('mysql2/promise');

async function setupDatabase() {
    const password = '12345';
    let connection;
    
    try {
        // 创建主连接
        connection = await mysql.createConnection({
            host: 'localhost',
            user: 'root',
            password: password
        });

        console.log(' 连接到 MySQL 服务器');

        // 步骤1: 创建数据库（如果不存在）
        await connection.query('CREATE DATABASE IF NOT EXISTS seller_management_test');
        console.log(' 数据库创建成功');

        // 使用新数据库
        await connection.query('USE seller_management_test');
        console.log(' 切换到测试数据库');

        // 步骤2: 删除已存在的表（如果存在）
        console.log('  清理旧表...');
        await connection.query('DROP TABLE IF EXISTS purchase_intents');
        await connection.query('DROP TABLE IF EXISTS products');
        await connection.query('DROP TABLE IF EXISTS seller');
        console.log(' 旧表清理完成');

        // 步骤3: 创建卖家表 - 使用最基本的SQL
        console.log(' 创建卖家表...');
        await connection.query(`
            CREATE TABLE seller (
                seller_id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) NOT NULL UNIQUE,
                password VARCHAR(100) NOT NULL,
                create_time DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);
        console.log(' 卖家表创建成功');

        // 步骤4: 创建商品表
        console.log(' 创建商品表...');
        await connection.query(`
            CREATE TABLE products (
                product_id INT AUTO_INCREMENT PRIMARY KEY,
                seller_id INT NOT NULL,
                product_name VARCHAR(100) NOT NULL,
                product_desc TEXT NOT NULL,
                image_url VARCHAR(255) NOT NULL,
                price DECIMAL(10,2) NOT NULL,
                product_status ENUM('online', 'frozen', 'sold') DEFAULT 'online',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (seller_id) REFERENCES seller(seller_id) ON DELETE CASCADE
            )
        `);
        console.log(' 商品表创建成功');

        // 步骤5: 创建购买意向表
        console.log(' 创建购买意向表...');
        await connection.query(`
            CREATE TABLE purchase_intents (
                purchase_id INT AUTO_INCREMENT PRIMARY KEY,
                product_id INT NOT NULL,
                customer_name VARCHAR(50) NOT NULL,
                customer_phone VARCHAR(20) NOT NULL,
                customer_address VARCHAR(255) NOT NULL,
                purchase_status ENUM('pending', 'success', 'failed') DEFAULT 'pending',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (product_id) REFERENCES products(product_id)
            )
        `);
        console.log(' 购买意向表创建成功');

        // 步骤6: 插入测试数据
        console.log(' 插入测试数据...');
        
        // 插入卖家
        await connection.query(`
            INSERT INTO seller (username, password) 
            VALUES ('admin', '$2a$12$ycJEdpJ1TYxBzDCmuGju2eUbTP.vm0yNYYyFpK3ahxsCLq9d2Iq32')
        `);
        console.log('卖家数据插入成功');

        // 插入商品
        await connection.query(`
            INSERT INTO products (seller_id, product_name, product_desc, image_url, price, product_status) 
            VALUES 
            (1, '笔记本电脑', '高性能游戏笔记本', 'https://picsum.photos/400/300', 5999.00, 'online'),
            (1, '智能手机', '最新款5G手机', 'https://picsum.photos/401/300', 3999.00, 'online'),
            (1, '无线耳机', '降噪蓝牙耳机', 'https://picsum.photos/402/300', 899.00, 'frozen'),
            (1, '平板电脑', '便携办公学习', 'https://picsum.photos/403/300', 2999.00, 'sold'),
            (1, '智能手表', '健康监测运动', 'https://picsum.photos/404/300', 1299.00, 'online')
        `);
        console.log(' 商品数据插入成功');

        // 插入购买意向
        await connection.query(`
            INSERT INTO purchase_intents (product_id, customer_name, customer_phone, customer_address, purchase_status) 
            VALUES
            (1, '张三', '13800138001', '北京市朝阳区建国路100号', 'pending'),
            (1, '李四', '13800138002', '上海市浦东新区陆家嘴', 'success'),
            (2, '王五', '13800138003', '广州市天河区珠江新城', 'pending'),
            (3, '赵六', '13800138004', '深圳市南山区科技园', 'failed'),
            (5, '钱七', '13800138005', '杭州市西湖区文三路', 'pending')
        `);
        console.log(' 购买意向数据插入成功');

        console.log(' 数据库初始化完成！');
        
    } catch (error) {
        console.error(' 数据库初始化失败:', error.message);
    } finally {
        if (connection) {
            await connection.end();
        }
    }
}

setupDatabase();